package com.project.controller;

import java.util.Objects;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.entities.Teacher;
import com.project.service.TeacherService;



@Controller
public class TeacherController {

	@Autowired
	private TeacherService teacherService;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("listUser", teacherService.getAllTeachersInfo());
		return "index";
	}
	
	@GetMapping("/loginForm")
	public String getLogin()
	{
		return "Login";
	}
	
	@PostMapping("/loginForm")
	public String login_user(@RequestParam("username") String username,@RequestParam("password") String password,
			HttpSession session,Model model)
	{
		
	Teacher auser = teacherService.findByUsernamePassword(username, password);
	
	if(auser!=null)
	{
		String uname=auser.getName();
		String upass=auser.getPassword();
	
		if(username.equalsIgnoreCase(uname) && password.equalsIgnoreCase(upass)) 
		{
			return "index";
		}
		else 
		{
			
			return "Login";
		}
	}
	else
	{
		model.addAttribute("logError","logError");
        return "Login";
	}
	
	}
	 

	@GetMapping("/showNewForm")
	public String showNewForm(Model model) {
		Teacher teacher = new Teacher();
		model.addAttribute("teacher", teacher);
		return "Register";
	}
	
	@PostMapping("/saveNewTeacherInfo")
	public String addTeacherInfo(@ModelAttribute Teacher teacher, Model model) {
		this.teacherService.saveTeacherInfo(teacher);
		return "redirect:/";
	}
	
	
}
