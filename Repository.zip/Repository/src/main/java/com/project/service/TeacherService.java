package com.project.service;

import java.util.List;

import com.project.entities.Teacher;

public interface TeacherService {
	
    List<Teacher> getAllTeachersInfo();
	
	void saveTeacherInfo(Teacher teacher);
	
	Teacher getTeacherInfoById(long teacherId);
	
	void deleteTeacherInfoById(long teacherId);

	Teacher findByUsernamePassword(String username, String password);
	
	
}
