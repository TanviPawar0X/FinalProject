package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.entities.Teacher;
import com.project.respository.TeacherRepository;

@Service
public class TeacherServiceImpl implements TeacherService {

	@Autowired
	private TeacherRepository teacherRepository;
	
	
	@Override
	public List<Teacher> getAllTeachersInfo() {
		return this.teacherRepository.findAll();
	}

	@Override
	public void saveTeacherInfo(Teacher teacher) {
		this.teacherRepository.save(teacher);
	}

	@Override
	public Teacher getTeacherInfoById(long teacherId) {
		return this.teacherRepository.getById(teacherId);
	}

	@Override
	public void deleteTeacherInfoById(long teacherId) {
		this.teacherRepository.deleteById(teacherId);
	}

	@Override
	public Teacher findByUsernamePassword(String username, String password) {
		return this.teacherRepository.findByUsernamePassword(username, password);
	}

}
