package com.project.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="teacher")
public class Teacher {
	

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="teacher_id")
		private long teacherId;
		
		@Column(name="name")
		private String name;
		
		@Column(name="module")
		private String module;
		
		@Column(name="email_id")
		private String emailId;
		
		@Column(name="mobile_no")
		private String mobile;
		
		@Column(name="password")
		private String password;

		public Teacher() {
			super();
		}

		public Teacher(long teacherId, String name, String module, String emailId, String mobile, String password) {
			super();
			this.teacherId = teacherId;
			this.name = name;
			this.module = module;
			this.emailId = emailId;
			this.mobile = mobile;
			this.password = password;
		}

		public Teacher(String name, String module, String emailId, String mobile, String password) {
			super();
			this.name = name;
			this.module = module;
			this.emailId = emailId;
			this.mobile = mobile;
			this.password = password;
		}

		public long getTeacherId() {
			return teacherId;
		}

		public void setTeacherId(long teacherId) {
			this.teacherId = teacherId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getModule() {
			return module;
		}

		public void setModule(String module) {
			this.module = module;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		@Override
		public String toString() {
			return "Teacher [teacherId=" + teacherId + ", name=" + name + ", module=" + module + ", emailId=" + emailId
					+ ", mobile=" + mobile + ", password=" + password + "]";
		}
		
		
		
}
