package com.project.security;

public class QRBTeacher {

}
