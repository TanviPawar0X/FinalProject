package student.result.service;

import java.util.List;

import student.result.entities.Student;

public interface StudentService {

	//list all the methods to interact with DB
	
	List <Student> getAllStudents();
	void saveStudent(Student student);
	Student getStudentById(long studentId);
		
	void deleteStudentById(long studentId);
}
