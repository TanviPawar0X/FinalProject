package student.result.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import student.result.entities.Student;
import student.result.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public List<Student> getAllStudents() {
		
		return this.studentRepository.findAll();
		
		
	}

	@Override
	public void saveStudent(Student student) {
	this.studentRepository.save(student);
		
	}

	@Override
	public Student getStudentById(long studentId) {
		return this.studentRepository.getById(studentId);
		
	}

	@Override
	public void deleteStudentById(long studentId) {
		this.studentRepository .deleteById(studentId);
		
	}

}
