package student.result.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.sun.istack.NotNull;

@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	 
		@NotNull()
	  private String name;
	  private String password;
	  private String email;
	  private String sub_math;
	  private String sub_sci;
	  private String sub_soci;
	  private String sub_engl;
	  private String sub_hindi;
	  public Student() {
	    super();

	  }
	  public Student(long id, String name, String password, String email, String sub_math, String sub_sci,
	      String sub_soci, String sub_engl, String sub_hindi) {
	    super();
	    this.id = id;
	    this.name = name;
	    this.password = password;
	    this.email = email;
	    this.sub_math = sub_math;
	    this.sub_sci = sub_sci;
	    this.sub_soci = sub_soci;
	    this.sub_engl = sub_engl;
	    this.sub_hindi = sub_hindi;
	  }
	  public long getId() {
	    return id;
	  }
	  public void setId(long id) {
	    this.id = id;
	  }
	  public String getName() {
	    return name;
	  }
	  public void setName(String name) {
	    this.name = name;
	  }
	  public String getPassword() {
	    return password;
	  }
	  public void setPassword(String password) {
	    this.password = password;
	  }
	  public String getEmail() {
	    return email;
	  }
	  public void setEmail(String email) {
	    this.email = email;
	  }
	  public String getSub_math() {
	    return sub_math;
	  }
	  public void setSub_math(String sub_math) {
	    this.sub_math = sub_math;
	  }
	  public String getSub_sci() {
	    return sub_sci;
	  }
	  public void setSub_sci(String sub_sci) {
	    this.sub_sci = sub_sci;
	  }
	  public String getSub_soci() {
	    return sub_soci;
	  }
	  public void setSub_soci(String sub_soci) {
	    this.sub_soci = sub_soci;
	  }
	  public String getSub_engl() {
	    return sub_engl;
	  }
	  public void setSub_engl(String sub_engl) {
	    this.sub_engl = sub_engl;
	  }
	  public String getSub_hindi() {
	    return sub_hindi;
	  }
	  public void setSub_hindi(String sub_hindi) {
	    this.sub_hindi = sub_hindi;
	  }
	  @Override
	  public String toString() {
	    return "Student [id=" + id + ", name=" + name + ", password=" + password + ", email=" + email + ", sub_math="
	        + sub_math + ", sub_sci=" + sub_sci + ", sub_soci=" + sub_soci + ", sub_engl=" + sub_engl
	        + ", sub_hindi=" + sub_hindi + "]";
	  }
	  }